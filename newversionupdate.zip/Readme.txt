MANUAL: 
1) Unzip all files from archive 
3) Go to archive Newversionupdate.zip
4) Unzip achive Version_Unlimited.rar (PASSWORD 1234)
5) Run file: Setup.exe